<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <?php if($compras_sin_facturar == 0): ?>
         <button class="btn btn-success btn-sm" disabled type="button">Sin Compras</button>
        <?php else: ?>
        <a href="<?php echo e(route("factura.facturar")); ?>" class="btn btn-success btn-sm">Facturar <?php echo e($compras_sin_facturar); ?> compras</a>
        <?php endif; ?>


        <div class="text-center">
            <h1>Facturacion</h1>
        </div>


        <?php if(session('message')): ?>
            <div class="my-4 alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="mt-4">

            <table class="table table-light">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Numero De Factura</th>
                        <th>Cliente</th>
                        
                        <th>Botones</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($factura->id); ?></td>
                            <td><?php echo e($factura->cliente->name); ?></td>
                            
                            <td>
                                <a href="<?php echo e(route("factura.show", ["factura" => $factura->id])); ?>" class="btn btn-primary btn-sm">Ver</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>


            </table>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abogados-prueba\resources\views/factura/index.blade.php ENDPATH**/ ?>