<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

        <?php if(auth()->user()->rol == "admin"): ?>
            <a href="<?php echo e(route("producto.create")); ?>" class="btn btn-success btn-sm">Crear Producto</a>
        <?php endif; ?>

        <div class="text-center">
            <h1>Lista De Productos</h1>
        </div>


        <?php if(session('message')): ?>
            <div class="my-4 alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="mt-4">

            <table class="table table-light">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Precio (Impuesto Incluido)</th>
                        <th>Botones</th>
                    </tr>
                </thead>

                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td> <?php echo e($i + 1); ?> </td>
                            <td> <?php echo e($producto->nombre); ?> </td>
                            <td> <?php echo e($producto->precio_con_impuesto); ?> </td>
                            <td>
                                <form action="<?php echo e(route('producto.compra', ['producto' => $producto->id])); ?>" class="d-inline"
                                    method="POST">
                                    <?php echo csrf_field(); ?>

                                    <button class="btn btn-warning btn-sm" type="submit">Comprar</button>
                                </form>

                                <?php if( auth()->user()->rol ==  "admin" ): ?>
                                    <a href="<?php echo e(route("producto.edit", ["producto" => $producto->id])); ?>" class="btn btn-success btn-sm">Editar</a>

                                    <form class="d-inline" action="<?php echo e(route("producto.destroy", ["producto" => $producto->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>

                                        <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>
                                    </form>

                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            <div class="d-flex justify-content-center">
                <?php echo e($productos->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abogados-prueba\resources\views/producto/index.blade.php ENDPATH**/ ?>