<?php $__env->startSection('content'); ?>
    <div class="container mt-4">

            <a href="<?php echo e(route("factura.index")); ?>" class="btn btn-success btn-sm">volver</a>


        <div class="text-center">
            <h1>Factura N' <?php echo e($factura->id); ?> Para Cliente <?php echo e($factura->cliente->name); ?></h1>
        </div>


        <?php if(session('message')): ?>
            <div class="my-4 alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="mt-4">

                        <?php
                            $total_precio = 0;
                            $total_impuesto = 0;
                            $total_precio_impuesto = 0;
                        ?>
            <table class="table table-light">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        
                        <th>precio</th>
                        <th>% impuesto</th>
                        <th>Precio Con Impuesto</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $factura->compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $precio_sin_impuesto = $compra->producto->precio_con_impuesto * ((100 - $compra->producto->procentaje_impuesto) * 0.01);

                            $total_precio += $precio_sin_impuesto;
                            $total_impuesto += $compra->producto->procentaje_impuesto;
                            $total_precio_impuesto += $compra->producto->precio_con_impuesto;
                        ?>

                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($compra->producto->nombre); ?></td>
                            
                            <td><?php echo e($precio_sin_impuesto); ?></td>
                            <td><?php echo e($compra->producto->procentaje_impuesto); ?></td>
                            <td><?php echo e($compra->producto->precio_con_impuesto); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

                <tfoot>
                    <tr>
                        <th></th>
                        <th></th>
                        <th><?php echo e($total_precio); ?></th>
                        <th><?php echo e($total_impuesto); ?></th>
                        <th><?php echo e($total_precio_impuesto); ?></th>
                    </tr>
                </tfoot>
            </table>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abogados-prueba\resources\views/factura/show.blade.php ENDPATH**/ ?>